<?php if (count(get_included_files()) === 1) { http_response_code(403); exit; } ?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#009966">
<title><?= e($PAGE['title']) ?> • LaundryPOS</title>
<link rel="stylesheet" href="assets/style.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/style.css') ?>">
</head>
<body>
<div class="shell">
  <header class="appbar">
    <div class="appbar-row">
      <div class="minw">
        <h1><?= e($PAGE['title']) ?></h1>
        <p><?= e($PAGE['sub']) ?></p>
      </div>
      <?php if (($PAGE['id'] ?? '') === 'transaksi'): ?>
      <button type="button" class="kasir-chip" id="kasir-chip" aria-label="Ubah nama kasir">
        <?= icon('userround', 'ic ic-sm') ?>
        <span>Kasir: <b id="kasir-nama">Andi</b></span>
        <?= icon('pencil', 'ic ic-xs') ?>
      </button>
      <?php endif; ?>
    </div>
    <p class="appbar-tgl"><?= e(tgl_header()) ?></p>
  </header>

  <main class="content">
