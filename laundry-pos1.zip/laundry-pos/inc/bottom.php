<?php if (count(get_included_files()) === 1) { http_response_code(403); exit; } ?>
  </main>

  <nav class="bottomnav" aria-label="Navigasi utama">
    <a href="index.php" class="<?= ($PAGE['id'] ?? '') === 'transaksi' ? 'aktif' : '' ?>">
      <?= icon('cart') ?><span>Transaksi</span>
    </a>
    <a href="laporan.php" class="<?= ($PAGE['id'] ?? '') === 'laporan' ? 'aktif' : '' ?>">
      <?= icon('chart') ?><span>Laporan</span>
    </a>
    <a href="pengaturan.php" class="<?= ($PAGE['id'] ?? '') === 'pengaturan' ? 'aktif' : '' ?>">
      <?= icon('settings') ?><span>Pengaturan</span>
    </a>
  </nav>
</div>

<dialog id="kasir-dialog" class="dialog">
  <h3>Nama kasir</h3>
  <p class="dialog-sub">Tercantum pada struk &amp; laporan transaksi.</p>
  <input id="kasir-input" class="input" maxlength="30" placeholder="cth: Andi">
  <div class="dialog-actions">
    <button type="button" class="btn btn-outline" id="kasir-batal">Batal</button>
    <button type="button" class="btn btn-primary" id="kasir-simpan">Simpan</button>
  </div>
</dialog>

<script src="assets/app.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/app.js') ?>"></script>
</body>
</html>
