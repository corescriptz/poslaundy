<?php
/**
 * LaundryPOS — inti aplikasi: koneksi database & fungsi bantu.
 * Dipakai oleh semua halaman. Tidak perlu diedit.
 */

declare(strict_types=1);

if (count(get_included_files()) === 1) {
    http_response_code(403);
    exit('Akses langsung tidak diizinkan.');
}

const HARI   = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const HARI_S = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const BULAN  = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

/** Escape output HTML */
function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/** Halaman pemberitahuan ramah saat ada yang belum disetel */
function mati(string $judul, string $pesan): void
{
    http_response_code(500);
    echo '<!doctype html><html lang="id"><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1"><title>' . e($judul) . '</title>'
        . '<body style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f4f4f5;padding:28px;margin:0">'
        . '<div style="max-width:560px;margin:auto;background:#fff;border:1px solid #e4e4e7;border-radius:16px;padding:24px">'
        . '<h1 style="font-size:18px;margin:0 0 10px">' . e($judul) . '</h1>'
        . '<div style="color:#3f3f46;line-height:1.7;font-size:14px">' . $pesan . '</div>'
        . '</div></body></html>';
    exit;
}

/* ---------- Koneksi database ---------- */
if (!is_file(__DIR__ . '/../config.php')) {
    mati('config.php tidak ditemukan', 'Pastikan file <b>config.php</b> ada di folder yang sama dengan index.php.');
}
$config = require __DIR__ . '/../config.php';

date_default_timezone_set($config['timezone'] ?? 'Asia/Jakarta');

$driver = getenv('LAUNDRY_DB_DRIVER') ?: 'mysql';

try {
    if ($driver === 'sqlite') { // khusus pengembangan lokal
        $path = getenv('LAUNDRY_SQLITE_PATH') ?: (__DIR__ . '/../data/app.sqlite');
        $pdo = new PDO('sqlite:' . $path);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    } else {
        $dsn = "mysql:host={$config['db_host']};port=" . (int)($config['db_port'] ?? 3306)
             . ";dbname={$config['db_name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
} catch (Throwable $ex) {
    if ($driver === 'mysql') {
        mati(
            'Belum bisa terhubung ke database',
            'Cek tiga hal ini, biasanya sudah selesai setelahnya:<br><br>'
            . '1. Buka file <b>config.php</b>, lalu ganti <b>db_name</b>, <b>db_user</b>, dan <b>db_pass</b> '
            . 'sesuai database yang dibuat di cPanel &rarr; MySQL&reg; Databases.<br>'
            . '2. Di cPanel, nama database &amp; user berawalan nama akun hosting, contoh: <code>tokoku_laundry</code>.<br>'
            . '3. Pastikan file <b>laundry-pos.sql</b> sudah di-<i>import</i> lewat phpMyAdmin ke database tersebut.'
        );
    }
    throw $ex;
}

/* ---------- Format angka, rupiah, tanggal ---------- */

function rupiah($n): string
{
    return 'Rp ' . number_format((float)$n, 0, ',', '.');
}

function angka($n): string
{
    return number_format((float)$n, 0, ',', '.');
}

/** 3,5 kg / 12 pcs */
function fmt_qty($n): string
{
    $s = number_format((float)$n, 2, ',', '.');
    $s = rtrim($s, '0');
    return rtrim($s, ',');
}

/** "15.000" / "15,5" -> 15000 / 15.5 */
function parse_angka(?string $s): float
{
    $c = preg_replace('/[^0-9,]/', '', (string)$s);
    $c = str_replace(',', '.', $c);
    return $c === '' ? 0.0 : (float)$c;
}

/** "Rp 15.000" / "15000" -> 15000 */
function parse_rupiah(?string $s): int
{
    $d = preg_replace('/\D/', '', (string)$s);
    return $d === '' ? 0 : (int)$d;
}

/** "Kamis, 6 Nov" untuk header aplikasi */
function tgl_header(): string
{
    return HARI[(int)date('w')] . ', ' . date('j') . ' ' . BULAN[(int)date('n') - 1];
}

/** "6 Nov 2026, 14.05" untuk struk */
function tgl_jam(?string $dt): string
{
    if (!$dt) return '-';
    $ts = strtotime($dt);
    return date('j', $ts) . ' ' . BULAN[(int)date('n', $ts) - 1] . ' ' . date('Y', $ts) . ', ' . date('H.i', $ts);
}

/** "6 Nov, 14.05" untuk baris daftar */
function tgl_pendek(?string $dt): string
{
    if (!$dt) return '-';
    $ts = strtotime($dt);
    return date('j', $ts) . ' ' . BULAN[(int)date('n', $ts) - 1] . ', ' . date('H.i', $ts);
}

/** Ringkas: 1,2jt / 45rb */
function ringkas($n): string
{
    $n = (int)$n;
    if ($n >= 1000000) {
        $v = $n / 1000000;
        $s = ($v == (int)$v) ? number_format($v, 0, ',', '.') : number_format($v, 1, ',', '.');
        return $s . 'jt';
    }
    if ($n >= 1000) return round($n / 1000) . 'rb';
    return (string)$n;
}

/* ---------- Query bantu ---------- */

function q(PDO $pdo, string $sql, array $params = []): PDOStatement
{
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st;
}

function get_store(PDO $pdo): array
{
    $row = q($pdo, "SELECT * FROM store_settings WHERE id = 'main'")->fetch();
    return $row ?: ['id' => 'main', 'name' => '', 'phone' => '', 'address' => ''];
}

function get_packages(PDO $pdo, bool $onlyActive = false): array
{
    $sql = 'SELECT * FROM packages';
    if ($onlyActive) $sql .= ' WHERE active = 1';
    $sql .= ' ORDER BY sort_order ASC, id ASC';
    return q($pdo, $sql)->fetchAll();
}

/** Tarif per satuan untuk sebuah paket */
function tarif_paket(array $p, string $unit, bool $express): int
{
    if ($express) return (int)($unit === 'KG' ? $p['express_per_kg'] : $p['express_per_pcs']);
    return (int)($unit === 'KG' ? $p['price_per_kg'] : $p['price_per_pcs']);
}

function get_txn(PDO $pdo, int $id): ?array
{
    $row = q($pdo, 'SELECT * FROM transactions WHERE id = ?', [$id])->fetch();
    return $row ?: null;
}

/** Statistik untuk halaman Laporan (zona WIB) */
function hitung_stats(PDO $pdo): array
{
    $today   = date('Y-m-d');
    $sToday  = $today . ' 00:00:00';
    $eToday  = date('Y-m-d 00:00:00', strtotime('+1 day'));
    $sYest   = date('Y-m-d 00:00:00', strtotime('-1 day'));
    $sMinggu = date('Y-m-d 00:00:00', strtotime('-6 day'));

    $todayRevenue  = (int)q($pdo, 'SELECT COALESCE(SUM(total),0) FROM transactions WHERE created_at >= ? AND created_at < ?', [$sToday, $eToday])->fetchColumn();
    $todayCount    = (int)q($pdo, 'SELECT COUNT(*) FROM transactions WHERE created_at >= ? AND created_at < ?', [$sToday, $eToday])->fetchColumn();
    $doneCount     = (int)q($pdo, "SELECT COUNT(*) FROM transactions WHERE status = 'DONE'")->fetchColumn();
    $expressCount  = (int)q($pdo, 'SELECT COUNT(*) FROM transactions WHERE express = 1 AND created_at >= ? AND created_at < ?', [$sToday, $eToday])->fetchColumn();
    $yesterRevenue = (int)q($pdo, 'SELECT COALESCE(SUM(total),0) FROM transactions WHERE created_at >= ? AND created_at < ?', [$sYest, $sToday])->fetchColumn();

    $rows = q($pdo, 'SELECT created_at, total FROM transactions WHERE created_at >= ? AND created_at < ?', [$sMinggu, $eToday])->fetchAll();
    $perDay = [];
    foreach ($rows as $r) {
        $d = substr((string)$r['created_at'], 0, 10);
        $perDay[$d] = ($perDay[$d] ?? 0) + (int)$r['total'];
    }
    $week = [];
    for ($i = 6; $i >= 0; $i--) {
        $key = date('Y-m-d', strtotime("-{$i} day"));
        $week[] = [
            'key'     => $key,
            'label'   => HARI_S[(int)date('w', strtotime($key))],
            'total'   => $perDay[$key] ?? 0,
            'isToday' => $key === $today,
        ];
    }

    $recent = q($pdo, 'SELECT * FROM transactions ORDER BY created_at DESC, id DESC LIMIT 15')->fetchAll();

    return [
        'todayRevenue'     => $todayRevenue,
        'todayCount'       => $todayCount,
        'doneCount'        => $doneCount,
        'expressCount'     => $expressCount,
        'expressPct'       => $todayCount > 0 ? (int)round($expressCount * 100 / $todayCount) : 0,
        'avgTicket'        => $todayCount > 0 ? intdiv($todayRevenue, $todayCount) : 0,
        'yesterRevenue'    => $yesterRevenue,
        'revenueChangePct' => $yesterRevenue > 0 ? (int)round(($todayRevenue - $yesterRevenue) * 100 / $yesterRevenue) : null,
        'week'             => $week,
        'recent'           => $recent,
    ];
}

/** Nomor nota berikutnya: A-1037, A-1038, ... */
function nota_berikutnya(PDO $pdo): string
{
    $rows = q($pdo, 'SELECT invoice_no FROM transactions')->fetchAll(PDO::FETCH_COLUMN);
    $last = 1023; // sama seperti aplikasi sebelumnya: mulai dari A-1024 jika database kosong
    foreach ($rows as $r) {
        $n = (int)preg_replace('/\D/', '', (string)$r);
        if ($n > $last) $last = $n;
    }
    return 'A-' . ($last + 1);
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

/* ---------- Potongan HTML bantu ---------- */

function icon(string $name, string $cls = 'ic'): string
{
    static $P = [
        'cart'      => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>',
        'chart'     => '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
        'settings'  => '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
        'user'      => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'check'     => '<path d="M20 6 9 17l-5-5"/>',
        'zap'       => '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
        'pen'       => '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
        'minus'     => '<path d="M5 12h14"/>',
        'plus'      => '<path d="M5 12h14"/><path d="M12 5v14"/>',
        'printer'   => '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>',
        'receipt'   => '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M14 8H8"/><path d="M16 12H8"/><path d="M13 16H8"/>',
        'trash'     => '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/>',
        'store'     => '<path d="M3 9l1.5-5h15L21 9"/><path d="M3 9h18"/><path d="M4 9v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9"/><path d="M9 21v-6h6v6"/>',
        'save'      => '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/>',
        'userround' => '<circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/>',
        'pencil'    => '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
        'wallet'    => '<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
        'bag'       => '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
        'percent'   => '<line x1="19" x2="5" y1="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
        'coins'     => '<circle cx="8" cy="8" r="6"/><path d="M18.09 10.37A6 6 0 1 1 10.34 18"/><path d="M7 6h1v4"/><path d="m16.71 13.88.7.71-2.82 2.82"/>',
    ];
    $d = $P[$name] ?? '';
    return '<svg class="' . e($cls) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
        . 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
}

/** Input uang dengan awalan Rp */
function money_input(string $name, int $value, string $aria, string $extra = ''): string
{
    $v = $value > 0 ? angka($value) : '';
    return '<div class="money-wrap"><span class="money-rp">Rp</span>'
        . '<input class="input money" type="text" inputmode="numeric" name="' . e($name) . '" id="' . e($name)
        . '" value="' . e($v) . '" placeholder="0" aria-label="' . e($aria) . '" ' . $extra . '></div>';
}

/** Badge status — semua transaksi langsung selesai */
function badge_selesai(): string
{
    return '<span class="badge-selesai">' . icon('check', 'ic ic-xs') . ' Selesai</span>';
}

/** Chip express kecil untuk baris transaksi */
function chip_express(): string
{
    return '<span class="chip-express">' . icon('zap', 'ic ic-xs') . ' Express</span>';
}
