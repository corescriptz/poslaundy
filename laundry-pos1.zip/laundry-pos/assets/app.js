/* LaundryPOS — logika sisi browser */
(function () {
  'use strict';

  /* ---------- Nama kasir (tersimpan di perangkat) ---------- */
  var kasirDialog = document.getElementById('kasir-dialog');
  var chip = document.getElementById('kasir-chip');
  var namaEl = document.getElementById('kasir-nama');
  var kasirHidden = document.getElementById('cashier-hidden');
  var kasirInput = document.getElementById('kasir-input');

  function getKasir() {
    try { return localStorage.getItem('laundry.cashier') || 'Andi'; } catch (e) { return 'Andi'; }
  }
  function setKasir(nama) {
    try { localStorage.setItem('laundry.cashier', nama); } catch (e) {}
    if (namaEl) namaEl.textContent = nama;
    if (kasirHidden) kasirHidden.value = nama;
  }
  setKasir(getKasir());

  if (chip && kasirDialog && kasirInput) {
    chip.addEventListener('click', function () {
      kasirInput.value = getKasir();
      kasirDialog.showModal();
    });
    document.getElementById('kasir-simpan').addEventListener('click', function () {
      setKasir(kasirInput.value.trim() || 'Andi');
      kasirDialog.close();
    });
    document.getElementById('kasir-batal').addEventListener('click', function () {
      kasirDialog.close();
    });
  }

  /* ---------- Format uang untuk semua input .money ---------- */
  function fmtAngka(n) {
    return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }
  function parseRupiah(str) {
    var d = String(str).replace(/\D/g, '');
    return d ? parseInt(d, 10) : 0;
  }
  Array.prototype.forEach.call(document.querySelectorAll('input.money'), function (el) {
    el.addEventListener('input', function () {
      var digits = el.value.replace(/\D/g, '');
      el.value = digits ? fmtAngka(parseInt(digits, 10)) : '';
      try { el.setSelectionRange(el.value.length, el.value.length); } catch (e) {}
    });
  });

  /* ---------- Hapus transaksi: konfirmasi 2 langkah ---------- */
  Array.prototype.forEach.call(document.querySelectorAll('.del-form'), function (f) {
    var ask = f.querySelector('.btn-del');
    var yes = f.querySelector('.btn-del-yes');
    if (!ask || !yes) return;
    ask.addEventListener('click', function () {
      ask.hidden = true;
      yes.hidden = false;
    });
    document.addEventListener('click', function (ev) {
      if (!f.contains(ev.target)) {
        ask.hidden = false;
        yes.hidden = true;
      }
    });
  });

  /* ---------- Halaman transaksi (kalkulasi) ---------- */
  var form = document.getElementById('pos-form');
  if (!form) return;

  var radios = form.querySelectorAll('input[name="package_id"]');
  var unitRadios = form.querySelectorAll('input[name="unit"]');
  var customerEl = document.getElementById('customer');
  var qtyEl = document.getElementById('qty');
  var qtyUnit = document.getElementById('qty-unit');
  var expressWrap = document.getElementById('express-wrap');
  var expressEl = document.getElementById('express');
  var customCard = document.getElementById('custom-card');
  var customName = document.getElementById('custom-name');
  var hitungEl = document.getElementById('hitung');
  var hitungAuto = document.getElementById('hitung-auto');
  var hitungCustom = document.getElementById('hitung-custom');
  var resetTotal = document.getElementById('reset-total');
  var totalEl = document.getElementById('total');
  var paidEl = document.getElementById('paid');
  var kembaliEl = document.getElementById('kembali');
  var kurangEl = document.getElementById('kurang');
  var submitBtn = document.getElementById('submit-btn');
  var submitLabel = document.getElementById('submit-label');

  var CUSTOM = 'custom';
  var manualTotal = null; // { key: configKey, value: angka } — hasil edit user utk paket terdaftar
  var customTotal = 0;    // total utk layanan bebas ("Lainnya")

  function selectedRadio(list) {
    for (var i = 0; i < list.length; i++) if (list[i].checked) return list[i];
    return null;
  }
  function fmtQty(n) {
    return n.toLocaleString('id-ID', { maximumFractionDigits: 2 });
  }
  function parseAngka(str) {
    var c = String(str).replace(/[^0-9,]/g, '').replace(',', '.');
    var v = parseFloat(c);
    return isNaN(v) ? 0 : v;
  }
  function unit() {
    var u = selectedRadio(unitRadios);
    return u ? u.value : 'KG';
  }
  function isCustom() {
    var p = selectedRadio(radios);
    return !!p && p.value === CUSTOM;
  }
  function pkgTerpilih() {
    var p = selectedRadio(radios);
    return p && p.value !== CUSTOM ? p : null;
  }
  function qty() {
    return parseAngka(qtyEl.value);
  }
  function configKey() {
    var p = selectedRadio(radios);
    return (p ? p.value : '') + '|' + unit() + '|' + qtyEl.value + '|' + (expressEl.checked ? '1' : '0');
  }
  function tarif(p, u, exp) {
    return exp
      ? (u === 'KG' ? +p.dataset.kgx : +p.dataset.pcsx)
      : (u === 'KG' ? +p.dataset.kg : +p.dataset.pcs);
  }
  function totalTerhitung() {
    var p = pkgTerpilih();
    if (!p) return 0;
    return Math.round(qty() * tarif(p, unit(), expressEl.checked));
  }
  function getTotal() {
    if (isCustom()) return customTotal;
    var t = totalTerhitung();
    var m = manualTotal;
    return (m && m.key === configKey() && m.value > 0) ? m.value : t;
  }

  function render() {
    /* tampilan pilihan aktif */
    Array.prototype.forEach.call(radios, function (r) {
      r.closest('.pkg-opt').classList.toggle('aktif', r.checked);
    });
    Array.prototype.forEach.call(unitRadios, function (r) {
      r.closest('.seg-item').classList.toggle('aktif', r.checked);
    });

    var custom = isCustom();
    var p = pkgTerpilih();

    customCard.hidden = !custom;
    expressWrap.hidden = custom;
    expressWrap.classList.toggle('on', expressEl.checked);

    /* harga di kartu paket mengikuti tarif express */
    Array.prototype.forEach.call(document.querySelectorAll('.zap-mini'), function (z) {
      z.hidden = !expressEl.checked;
    });
    Array.prototype.forEach.call(document.querySelectorAll('.pkg-price[data-base]'), function (el) {
      var r = el.closest('.pkg-opt').querySelector('input[name="package_id"]');
      if (!r || r.value === CUSTOM) return;
      var kg = expressEl.checked ? +r.dataset.kgx : +r.dataset.kg;
      var pcs = expressEl.checked ? +r.dataset.pcsx : +r.dataset.pcs;
      el.textContent = 'Rp ' + fmtAngka(kg) + '/kg\nRp ' + fmtAngka(pcs) + '/pcs';
    });

    qtyUnit.textContent = unit() === 'KG' ? 'kg' : 'pcs';

    var total = getTotal();
    var tAuto = totalTerhitung();
    var edited = !custom && !!p && manualTotal && manualTotal.key === configKey()
              && manualTotal.value > 0 && manualTotal.value !== tAuto;

    if (custom) {
      hitungEl.textContent = 'Tarif manual \u2014 atur jumlah & total sendiri';
      hitungCustom.hidden = false;
      hitungAuto.hidden = true;
      resetTotal.hidden = true;
      if (parseRupiah(totalEl.value) !== customTotal) {
        totalEl.value = customTotal ? fmtAngka(customTotal) : '';
      }
    } else if (p) {
      hitungEl.textContent = fmtQty(qty()) + ' ' + (unit() === 'KG' ? 'kg' : 'pcs')
        + ' \u00d7 Rp ' + fmtAngka(tarif(p, unit(), expressEl.checked));
      hitungCustom.hidden = true;
      resetTotal.hidden = !edited;
      hitungAuto.hidden = !edited;
      if (edited) hitungAuto.textContent = 'Hitungan otomatis: Rp ' + fmtAngka(tAuto);
      var shown = (manualTotal && manualTotal.key === configKey() && manualTotal.value > 0)
        ? manualTotal.value : tAuto;
      if (parseRupiah(totalEl.value) !== shown) {
        totalEl.value = shown ? fmtAngka(shown) : '';
      }
    } else {
      hitungEl.textContent = 'Pilih paket untuk melihat total';
      hitungCustom.hidden = true;
      hitungAuto.hidden = true;
      resetTotal.hidden = true;
      totalEl.value = '';
    }

    var paid = parseRupiah(paidEl.value);
    var kembali = paid > total ? paid - total : 0;
    var kurang = paid > 0 && paid < total ? total - paid : 0;
    kembaliEl.textContent = 'Rp ' + fmtAngka(kembali);
    kurangEl.hidden = kurang === 0;
    kurangEl.textContent = 'Uang bayar kurang Rp ' + fmtAngka(kurang);

    var ok = !!customerEl.value.trim() && qty() > 0 && kurang === 0 &&
             (custom ? (!!customName.value.trim() && total > 0) : !!p);
    submitBtn.disabled = !ok;
    submitLabel.textContent = 'Simpan Transaksi' + (total > 0 ? ' \u2022 Rp ' + fmtAngka(total) : '');
  }

  Array.prototype.forEach.call(radios, function (r) {
    r.addEventListener('change', function () { manualTotal = null; customTotal = 0; render(); });
  });
  Array.prototype.forEach.call(unitRadios, function (r) {
    r.addEventListener('change', function () { manualTotal = null; render(); });
  });
  expressEl.addEventListener('change', function () { manualTotal = null; render(); });
  qtyEl.addEventListener('input', function () { manualTotal = null; render(); });
  customerEl.addEventListener('input', render);
  customName.addEventListener('input', render);

  totalEl.addEventListener('input', function () {
    var v = parseRupiah(totalEl.value);
    if (isCustom()) customTotal = v;
    else manualTotal = { key: configKey(), value: v };
    render();
  });
  paidEl.addEventListener('input', render);
  resetTotal.addEventListener('click', function () { manualTotal = null; render(); });

  Array.prototype.forEach.call(document.querySelectorAll('.chip[data-paid]'), function (c) {
    c.addEventListener('click', function () {
      paidEl.value = c.dataset.paid === 'pas'
        ? (getTotal() > 0 ? fmtAngka(getTotal()) : '')
        : fmtAngka(parseInt(c.dataset.paid, 10));
      render();
    });
  });

  function stepQty(dir) {
    var u = unit();
    var st = u === 'KG' ? 0.5 : 1;
    var min = u === 'KG' ? 0.5 : 1;
    var next = Math.max(min, Math.round((qty() + dir * st) * 100) / 100);
    qtyEl.value = fmtQty(next);
    manualTotal = null;
    render();
  }
  document.getElementById('qty-minus').addEventListener('click', function () { stepQty(-1); });
  document.getElementById('qty-plus').addEventListener('click', function () { stepQty(1); });

  render();
})();
