<?php
/** Cetak laporan harian */
require __DIR__ . '/../inc/app.php';

$stats = hitung_stats($pdo);
$store = get_store($pdo);
$toko  = trim((string)$store['name']) !== '' ? $store['name'] : 'LaundryPOS';

$todayKey = date('Y-m-d');
$todayTxns = array_values(array_filter(
    $stats['recent'],
    fn(array $t) => substr((string)$t['created_at'], 0, 10) === $todayKey
));
$total = 0;
foreach ($todayTxns as $t) $total += (int)$t['total'];
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Laporan Harian</title>
<style>
  @page { size: A4 portrait; margin: 12mm; }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 24px 12px; background: #e8e8e8; color: #000;
         font: 12px/1.5 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
  .page { max-width: 640px; margin: 0 auto; background: #fff; padding: 24px 28px; }
  .center { text-align: center; }
  .toko { font-size: 17px; font-weight: bold; }
  table { width: 100%; border-collapse: collapse; font-size: 11px; margin-top: 4px; }
  th, td { border: 1px solid #000; padding: 4px 6px; text-align: left; vertical-align: top; }
  th { font-weight: bold; }
  .box { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 24px; border: 1px solid #000; padding: 12px; margin-top: 16px; }
  .box div { display: flex; justify-content: space-between; gap: 8px; }
  h3 { font-size: 13px; margin: 16px 0 0; }
  .no-print { text-align: center; padding: 0 0 16px; }
  .no-print button { padding: 8px 18px; font-size: 14px; border: 0; border-radius: 8px; background: #009966; color: #fff; }
  @media print { body { background: #fff; padding: 0; } .no-print { display: none; } }
</style>
</head>
<body>
<div class="no-print"><button onclick="window.print()">Cetak ulang laporan</button></div>

<div class="page">
  <div class="center">
    <div class="toko"><?= e($toko) ?></div>
    <?php if (trim((string)$store['address']) !== ''): ?><div><?= nl2br(e($store['address'])) ?></div><?php endif; ?>
    <?php if (trim((string)$store['phone']) !== ''): ?><div>Telp: <?= e($store['phone']) ?></div><?php endif; ?>
    <div style="margin-top:4px">Laporan Harian &mdash; <?= e(tgl_jam(date('Y-m-d H:i:s'))) ?></div>
  </div>

  <div class="box">
    <div><span>Pendapatan hari ini</span><b><?= e(rupiah($stats['todayRevenue'])) ?></b></div>
    <div><span>Jumlah transaksi</span><b><?= (int)$stats['todayCount'] ?></b></div>
    <div><span>Transaksi selesai</span><span><?= (int)$stats['doneCount'] ?></span></div>
    <div><span>Order express</span><span><?= (int)$stats['expressCount'] ?> (<?= (int)$stats['expressPct'] ?>%)</span></div>
    <div><span>Rata-rata per transaksi</span><span><?= e(rupiah($stats['avgTicket'])) ?></span></div>
    <div><span>Pendapatan kemarin</span><span><?= e(rupiah($stats['yesterRevenue'])) ?></span></div>
  </div>

  <h3>Rincian transaksi hari ini (<?= count($todayTxns) ?>)</h3>
  <table>
    <thead>
      <tr><th>Nota</th><th>Pelanggan</th><th>Paket</th><th>Qty</th><th>Express</th><th>Total</th><th>Status</th></tr>
    </thead>
    <tbody>
      <?php if (count($todayTxns) === 0): ?>
      <tr><td colspan="7" style="text-align:center">Belum ada transaksi hari ini.</td></tr>
      <?php else: foreach ($todayTxns as $t): ?>
      <tr>
        <td><?= e($t['invoice_no']) ?></td>
        <td><?= e($t['customer_name']) ?></td>
        <td><?= e($t['package_name']) ?></td>
        <td><?= e(fmt_qty($t['qty'])) ?> <?= $t['unit'] === 'KG' ? 'kg' : 'pcs' ?></td>
        <td><?= $t['express'] ? 'Ya' : '-' ?></td>
        <td><?= e(rupiah($t['total'])) ?></td>
        <td>Selesai</td>
      </tr>
      <?php endforeach; ?>
      <tr>
        <td colspan="5"><b>Total</b></td>
        <td><b><?= e(rupiah($total)) ?></b></td>
        <td></td>
      </tr>
      <?php endif; ?>
    </tbody>
  </table>

  <p class="center" style="font-size:11px;margin-top:12px">Dicetak dari aplikasi LaundryPOS</p>
</div>

<script>window.addEventListener('load', () => setTimeout(() => { try { window.print(); } catch (e) {} }, 250));</script>
</body>
</html>
