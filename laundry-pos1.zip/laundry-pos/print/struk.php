<?php
/** Cetak struk termal 80mm */
require __DIR__ . '/../inc/app.php';

$id  = (int)($_GET['id'] ?? 0);
$txn = $id > 0 ? get_txn($pdo, $id) : null;
if (!$txn) {
    http_response_code(404);
    mati('Struk tidak ditemukan', 'Nomor transaksi tidak ada di database.');
}
$store  = get_store($pdo);
$toko   = trim((string)$store['name']) !== '' ? $store['name'] : 'LaundryPOS';
$alamat = trim((string)$store['address']);
$telp   = trim((string)$store['phone']);
$uLabel = $txn['unit'] === 'KG' ? 'kg' : 'pcs';
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Struk <?= e($txn['invoice_no']) ?></title>
<style>
  @page { size: 80mm auto; margin: 0; }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 6mm 0; background: #e8e8e8; }
  .struk {
    width: 72mm; margin: 0 auto; padding: 2mm 4mm;
    background: #fff; color: #000;
    font: 12px/1.55 "Courier New", Courier, monospace;
  }
  .row { display: flex; justify-content: space-between; gap: 2mm; }
  .row span:first-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .row span:last-child { white-space: nowrap; }
  .row.bold, .bold { font-weight: bold; }
  .dash { border-top: 1px dashed #000; margin: 2mm 0; }
  .center { text-align: center; }
  .toko { font-size: 13px; font-weight: bold; letter-spacing: .5px; }
  .no-print { text-align: center; padding: 6mm 0; font-family: system-ui, sans-serif; }
  .no-print button { padding: 8px 18px; font-size: 14px; border: 0; border-radius: 8px; background: #009966; color: #fff; }
  @media print {
    body { background: #fff; padding: 0; }
    .no-print { display: none; }
  }
</style>
</head>
<body>
<div class="no-print">
  <button onclick="window.print()">Cetak ulang struk</button>
</div>

<div class="struk">
  <div class="center">
    <div class="toko"><?= e($toko) ?></div>
    <?php if ($alamat !== ''): ?><div><?= nl2br(e($alamat)) ?></div><?php endif; ?>
    <?php if ($telp !== ''): ?><div>Telp: <?= e($telp) ?></div><?php endif; ?>
  </div>

  <div class="dash"></div>
  <div class="row"><span>No. Nota</span><span><?= e($txn['invoice_no']) ?></span></div>
  <div class="row"><span>Tanggal</span><span><?= e(tgl_jam($txn['created_at'])) ?></span></div>
  <div class="row"><span>Kasir</span><span><?= e($txn['cashier']) ?></span></div>
  <div class="row"><span>Pelanggan</span><span><?= e($txn['customer_name']) ?></span></div>

  <div class="dash"></div>
  <div class="row"><span><?= e($txn['package_name']) ?></span><span><?= e(rupiah($txn['unit_price'])) ?></span></div>
  <div class="row"><span><?= e(fmt_qty($txn['qty'])) ?> <?= $uLabel ?> x <?= e(rupiah($txn['unit_price'])) ?></span><span><?= e(rupiah($txn['total'])) ?></span></div>
  <?php if ($txn['express']): ?><div class="bold">* Layanan EXPRESS (selesai hari ini)</div><?php endif; ?>

  <div class="dash"></div>
  <div class="row bold"><span>TOTAL</span><span><?= e(rupiah($txn['total'])) ?></span></div>
  <div class="row"><span>Bayar</span><span><?= e(rupiah($txn['paid'])) ?></span></div>
  <div class="row"><span>Kembalian</span><span><?= e(rupiah($txn['change_amount'])) ?></span></div>

  <div class="dash"></div>
  <div class="center">Terima kasih sudah laundry di tempat kami!</div>
</div>

<script>window.addEventListener('load', () => setTimeout(() => { try { window.print(); } catch (e) {} }, 250));</script>
</body>
</html>
